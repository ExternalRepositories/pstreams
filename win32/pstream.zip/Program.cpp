#include "Program.h"

Program::Program()
{}
Program::Program(const string& path) : path(path)
{}
Program::~Program()
{}
